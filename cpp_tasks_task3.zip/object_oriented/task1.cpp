#include <iostream>
#include <cmath>

using namespace std;

class Triangle
{
private:
    double a;
    double b;

public:
    Triangle(double a, double b)
    {
        this->a = a;
        this->b = b;
    }

    double getHypotenuse()
    {
        return sqrt(a * a + b * b);
    }
};

int main()
{
    double a, b;
    cin >> a >> b;

    Triangle triangle(a, b);

    cout << triangle.getHypotenuse() << endl;

    return 0;
}
