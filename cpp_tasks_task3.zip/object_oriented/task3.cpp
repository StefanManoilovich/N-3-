#include <iostream>

using namespace std;

class Number
{
private:
    int n;

public:
    Number(int n)
    {
        this->n = n;
    }

    int getTens()
    {
        return (n / 10) % 10;
    }
};

int main()
{
    int n;
    cin >> n;

    Number number(n);

    cout << number.getTens() << endl;

    return 0;
}
