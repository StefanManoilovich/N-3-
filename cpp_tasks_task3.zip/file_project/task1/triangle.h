#ifndef TRIANGLE_H
#define TRIANGLE_H

double findHypotenuse(double a, double b);

#endif
