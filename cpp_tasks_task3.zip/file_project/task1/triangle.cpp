#include <cmath>
#include "triangle.h"

double findHypotenuse(double a, double b)
{
    return sqrt(a * a + b * b);
}
