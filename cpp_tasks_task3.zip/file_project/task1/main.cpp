#include <iostream>
#include "triangle.h"

using namespace std;

int main()
{
    double a, b;
    cin >> a >> b;

    cout << findHypotenuse(a, b) << endl;

    return 0;
}
