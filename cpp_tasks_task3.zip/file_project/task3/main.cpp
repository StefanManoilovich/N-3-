#include <iostream>
#include "number.h"

using namespace std;

int main()
{
    int n;
    cin >> n;

    cout << findTens(n) << endl;

    return 0;
}
