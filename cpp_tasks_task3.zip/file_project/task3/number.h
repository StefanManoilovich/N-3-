#ifndef NUMBER_H
#define NUMBER_H

int findTens(int n);

#endif
