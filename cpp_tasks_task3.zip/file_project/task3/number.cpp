#include "number.h"

int findTens(int n)
{
    return (n / 10) % 10;
}
