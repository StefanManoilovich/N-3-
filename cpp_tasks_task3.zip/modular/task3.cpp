#include <iostream>

using namespace std;

int findTens(int n)
{
    return (n / 10) % 10;
}

int main()
{
    int n;
    cin >> n;

    cout << findTens(n) << endl;

    return 0;
}
