#include <iostream>
#include <cmath>

using namespace std;

double findHypotenuse(double a, double b)
{
    return sqrt(a * a + b * b);
}

int main()
{
    double a, b;
    cin >> a >> b;

    cout << findHypotenuse(a, b) << endl;

    return 0;
}
